<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'local' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', 'root' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'smdU3nLO6zuQTlj+AZKdlk8r8YOPcSePOtFfoh+y/tdvG+SsN2w/kzEHoAsi69SBpaazr6oekz3I2eR/Jav01g==');
define('SECURE_AUTH_KEY',  'FD5XB1VgyhmYz1KQyJd5HeBoPHf0oLiEhDlW54O+OsHhU3+0EAUaY/6vxyHnt5scnNO8D+LcSxUdCudMUdZSZw==');
define('LOGGED_IN_KEY',    '2VaDvf6DoDe3ePq2SmKEWJB66+7ThF37AXpnDU/YrgmTilmtJe9JilHFBRMH0ZXKhdsqD6uGMmxu+sx+YC+eyQ==');
define('NONCE_KEY',        'VVdVojBiyRPku/Rx8yKCV9jIYKCkrfbaNfgPJ9L1u9WxN1SL9e4HkZcC5jYal0EqCXbthGh+HLrIIklTZXKkCA==');
define('AUTH_SALT',        'Cjt3vUbSUwExKP6Zdz7pTJvMCoypKMwRTynmBhy2G+mwBkWo4Q8Pf5ST/Ewm/4fK5prxIXUxmdu0RyxhGLlwbQ==');
define('SECURE_AUTH_SALT', 'tubCODSf9E3bCWx0ASiplugRm80ULJ9GUJkMFUkOMw9Anh+woXhtU8YgG9b+H+50f7ojPDfPJa3epp9Dv/hgfQ==');
define('LOGGED_IN_SALT',   '5r+4aHqnLcUADOHTg6vRQWo0/zls/ScdsAUnKi1WuMq9Jxls4ZOuLoM5mPLXBoaxqulw+HGPHP2GAtFCx052sg==');
define('NONCE_SALT',       'x67hIakX3Va4EGvRaoHAiXaEvWVHBy3aTQ0m67naEiUI7fV3WfuRKxaksgac03lV40W/8PuhcMC8Wt8jEck+EQ==');

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';




/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
